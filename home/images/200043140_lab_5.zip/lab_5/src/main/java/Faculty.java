public class Faculty extends Person{
    public String Designation;
    @Override
    public String toString()
    {
        return "This is Faculty";
    }
}
