public class FizzBuzz {
    public int n;
    public String getFizzyBuzz(int n)
    {
        if(n%3 == 0 && n%5 == 0) return "Fizzbuzz";
        else if (n%3 == 0) return "Fizz";
        else if (n%5 == 0) return "Buzz";
        else return "Boom";
    }
}
