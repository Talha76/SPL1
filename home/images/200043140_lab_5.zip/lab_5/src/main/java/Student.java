public class Student extends Person {
    public String StudentId;
    @Override
    public String toString()
    {
        return "This is Student";
    }
}
