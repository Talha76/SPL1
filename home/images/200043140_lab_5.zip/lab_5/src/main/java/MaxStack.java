import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Vector;

public class MaxStack {
    public Vector <Integer> stack = new Vector<Integer>();
    public Vector <Integer> Max = new Vector<Integer>();
    public Integer M = -1;
    public void push (Integer x)
    {
        if(x > M)
        {
            M = x;
        }
        Max.add(M);
        this.stack.add(x);
    }
    public void pop()
    {
        this.stack.remove(stack.size() - 1);
        this.Max.remove(Max.size() - 1);
    }
    public Integer max()
    {
        Integer lastElement = this.Max.lastElement();
        return lastElement;
    }
}
