public class Person {
    public String Name, Adress, Age;
    @Override
    public String toString()
    {
        return "This is Person";
    }
}
