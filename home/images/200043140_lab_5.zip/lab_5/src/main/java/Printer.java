import java.util.ArrayList;

public class Printer <T>{
    public T t;
    public ArrayList <T> list= new ArrayList<T>();
    public <T> String printList (ArrayList <T> list)
    {
        return "This is Printer Class";
    }
}
