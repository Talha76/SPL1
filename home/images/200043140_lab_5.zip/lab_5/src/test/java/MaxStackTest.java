import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class MaxStackTest {
    @Test
    void Test1()
    {
        MaxStack stack = new MaxStack();
        stack.push(3);
        stack.push(2);
        stack.push(5);
        stack.push(1);
        Integer expected = 5;
        assertEquals(expected, stack.max());
    }
    @Test
    void Test2()
    {
        MaxStack stack = new MaxStack();
        stack.push(3);
        stack.push(2);
        stack.push(5);
        stack.push(1);
        stack.pop();
        Integer expected = 5;
        assertEquals(expected, stack.max());
    }
    @Test
    void Test3()
    {
        MaxStack stack = new MaxStack();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        Integer expected = 4;
        assertEquals(expected, stack.max());
    }
    @Test
    void Test4()
    {
        MaxStack stack = new MaxStack();
        stack.push(1);
        stack.push(3);
        stack.push(4);
        stack.pop();
        Integer expected = 3;
        assertEquals(expected, stack.max());
    }
}
