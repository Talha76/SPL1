import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class fizzbuzz_test {
    @Test
    void fizz() {
        String expected = "Fizz";
        FizzBuzz fizzbuzz = new FizzBuzz();

        assertEquals(expected, fizzbuzz.getFizzyBuzz(3));
    }
    @Test
    void buzz() {
        String expected = "Buzz";
        FizzBuzz fizzbuzz = new FizzBuzz();

        assertEquals(expected, fizzbuzz.getFizzyBuzz(5));
    }
    @Test
    void fizzbuzz() {
        String expected = "Fizzbuzz";
        FizzBuzz fizzbuzz = new FizzBuzz();

        assertEquals(expected, fizzbuzz.getFizzyBuzz(15));
    }
    @Test
    void boom() {
        String expected = "Boom";
        FizzBuzz fizzbuzz = new FizzBuzz();

        assertEquals(expected, fizzbuzz.getFizzyBuzz(4));
    }
}
